playerdict = {}
testdict = {'test': 'Knight'}
classdict = { #HP, ATK, DEF, Initiative
    'Knight': [100, 30, 70, 4],
    'Spellcaster': [60, 100, 20, 3],
    'Ranger': [80, 50, 50, 5],
    'King' : [40, 5, 0, 5]
    }

# statsclass = { #HP, ATK, DEF
#     "KnightSTATS": [100, 30, 70],
#     "SpellcasterSTATS": [60, 100, 20],
#     "RangerSTATS": [80, 50, 50]
# }
enemydict = { #HP, ATK, DEF
    "Skeleton": [0, 30, 0, 7],
    "Zombie": [10, 10, 0, 1],
    "Slime": [50, 30, 0, 1],
    "Dragon": [50, 3, 0, 7],
    "DragonKing": [50, 20, 0, 7],
    "WalkingDead": [0, 3, 0, 2],
    "Balrog": [3000, 70, 20, 6]
}

enemylist = ["Skeleton", "Zombie", "Slime", "Balrog"]