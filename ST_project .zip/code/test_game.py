import unittest
from maingame import red_room

#def test_case_1(input1, input2, input3):
    #return red_room(input1, input2, input3)



#class red_room_Test(unittest.TestCase):

    #def test_case_1_success(self):
    #actual = test_case_1(3,"y", ["y", "n"])
    #expected = True
    #self.assertEqual(actual, expected)


class TestSum(unittest.TestCase):

    def test_path1(self):
        self.assertEqual(red_room("Zombie", "Knight", 3,["y"], ["y", "n"]), 8, "Should be 8")
    def test_path2(self):
        self.assertEqual(red_room("Slime", "Ranger", 1,["y", "y"], ["y", "n"]), 1, "Should be 1")
    def test_path3(self):
        self.assertEqual(red_room("Dragon", "Spellcaster",1,["y", "y"], ["y", "n"]), 4, "Should be 4")
    def test_path4(self):
        self.assertEqual(red_room("WalkingDead", "Spellcaster",1,["y", "y"], ["y", "n"]), 1, "Should be 1") 
    def test_path5(self):
        self.assertEqual(red_room("Skeleton", "Spellcaster",1,["y", "y"], ["y", "n"]), 4, "Should be 4")
    def test_path6(self):
        self.assertEqual(red_room("Slime", "King",1,["y", "y"], ["y", "n"]), 3, "Should be 3")
    def test_path7(self):
        self.assertEqual(red_room("DragonKing", "King",1,["y", "y"], ["y", "n"]), 6, "Should be 6")
    def test_path8(self):
        self.assertEqual(red_room("DragonKing", "Ranger", 1, ["y", "y"], ["y", "y"]), 4, "Should be 4")
    def test_path9(self):
        self.assertEqual(red_room("DragonKing", "Ranger", 1, ["n", "n"], ["n", "n"]), 5, "Should be 5")
    def test_path10(self):
        self.assertEqual(red_room("Dragon", "Spellcaster", 1, ["y", "y"], ["y", "y"]), 4, "Should be 4")
    def test_path11(self):
        self.assertEqual(red_room("Dragon", "Spellcaster", 1, ["n", "n"], ["n", "n"]), 5, "Should be 5")
    # du_paths
    # def test_path10(self):
    #     self.assertEqual(red_room("Dragon", "Ranger",2,["y", "n"], ["y", "n"]), True, "Should be True")
    #def test_sum_tuple(self):
        #self.assertEqual(sum((1, 2, 2)), 6, "Should be 6")

if __name__ == '__main__':
    unittest.main()         